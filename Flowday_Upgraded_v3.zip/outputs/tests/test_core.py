import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from smart_productivity.database import SQLiteTaskRepository
from smart_productivity.models import Task, DeadlinePriorityStrategy, completion_streak

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.repo = SQLiteTaskRepository(Path(self.temp.name) / "test.db")
        user = self.repo.register_user("Test User", "tester", "secret123")
        self.repo.set_user(user["id"])
    def tearDown(self): self.temp.cleanup()
    def test_task_round_trip_and_status(self):
        task = Task(None, "Read chapter", "Study", date.today().isoformat(), 35, "notes")
        self.repo.save_task(task)
        loaded = self.repo.list_tasks()[0]
        self.assertEqual(loaded.title, "Read chapter")
        self.assertEqual(loaded.category, "Study")
        loaded.mark_complete(); self.repo.save_task(loaded)
        self.assertTrue(self.repo.list_tasks()[0].completed)
    def test_delete_task(self):
        task=Task(None,"Remove me"); self.repo.save_task(task); self.repo.delete_task(task.id)
        self.assertEqual(self.repo.list_tasks(), [])
    def test_priority_policy_and_override(self):
        strategy=DeadlinePriorityStrategy(); today=date.today()
        self.assertEqual(strategy.calculate(Task(None,"Now",deadline=today.isoformat()),today),"High")
        self.assertEqual(strategy.calculate(Task(None,"Soon",deadline=(today+timedelta(days=2)).isoformat()),today),"Medium")
        t=Task(None,"Override",deadline=today.isoformat(),priority_override="Low")
        self.assertEqual(strategy.calculate(t,today),"Low")
    def test_study_session_lifecycle(self):
        session_id=self.repo.save_session("Math",date.today().isoformat()+" 09:30",25,"Algebra")
        self.assertEqual(len(self.repo.list_sessions(date.today().isoformat())),1)
        self.repo.toggle_session(session_id)
        self.assertEqual(self.repo.list_sessions(date.today().isoformat())[0]["completed"],1)
        self.repo.delete_session(session_id)
        self.assertEqual(len(self.repo.list_sessions(date.today().isoformat())),0)
    def test_login_and_user_isolation(self):
        self.assertIsNotNone(self.repo.authenticate_user("tester", "secret123"))
        self.assertIsNone(self.repo.authenticate_user("tester", "wrong-pass"))
        self.repo.save_task(Task(None, "Mine"))
        other = self.repo.register_user("Other Person", "other", "secret456"); self.repo.set_user(other["id"])
        self.assertEqual(self.repo.list_tasks(), [])
    def test_completion_date_is_recorded_and_cleared(self):
        t = Task(None, "Finish me"); t.mark_complete(); self.assertEqual(t.completed_at[:10], date.today().isoformat())
        self.repo.save_task(t); self.assertEqual(self.repo.list_tasks()[0].completed_at[:10], date.today().isoformat())
        t.mark_incomplete(); self.assertEqual(t.completed_at, "")
    def test_streak(self):
        today = date.today(); tasks = []
        for n in (0, 1, 2, 4):
            t = Task(None, f"t{n}"); t.mark_complete(); t.completed_at = (today - timedelta(days=n)).isoformat() + "T10:00:00"; tasks.append(t)
        self.assertEqual(completion_streak(tasks, today), 3)
        self.assertEqual(completion_streak([], today), 0)
    def test_demo_data_loads(self):
        self.repo.seed_demo_data()
        self.assertGreaterEqual(len(self.repo.list_tasks()), 10)
        self.assertEqual(len(self.repo.list_sessions(date.today().isoformat())), 4)
        self.assertGreaterEqual(completion_streak(self.repo.list_tasks()), 5)

if __name__ == "__main__": unittest.main()

