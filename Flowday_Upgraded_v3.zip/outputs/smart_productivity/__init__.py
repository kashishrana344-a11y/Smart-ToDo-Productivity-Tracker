"""Smart Productivity desktop app."""
