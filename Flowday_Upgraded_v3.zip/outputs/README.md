# Flowday — Smart To-Do & Productivity Tracker

A beginner-friendly desktop productivity app built with Python, Tkinter, and SQLite. It runs on Windows without installing third-party packages.

## Features

- **Dashboard:** open task, completed today, study-time, and due-soon summaries, priority focus, and quick actions.
- **Task manager:** create, edit, complete/reopen, delete, search by status filter, set categories, notes, estimates, deadlines, and automatic or manual priority.
- **Smart priority:** due today/overdue tasks are High, tasks due within three days or estimated at two hours or more are Medium, and other tasks are Low. Manual priority overrides are supported.
- **Daily study planner:** schedule study blocks, mark complete/reopen, and remove blocks.
- **Productivity insights:** weekly completed-task chart and completion-rate metrics.
- **Reminders:** a popup checks for due/overdue tasks when the app opens and once each minute while it stays open.
- **Accounts:** register / login (salted PBKDF2 hashes), Enter-key login, and a **Log out** button; every user sees only their own data.
- **Focus timer (Pomodoro):** 25/50-minute focus rounds, 5/15-minute breaks and a 10-second demo mode. Finished focus rounds are logged automatically in the Study planner.
- **Smarter dashboard:** time-based greeting, overall progress bar, completion streak and one-click sample data for demos.
- **Task manager extras:** live search, overdue tasks highlighted in red, priority/category dropdowns, Today / Tomorrow / +7 days deadline buttons, and **Export to CSV**.
- **Better insights:** charts now use the real completion date, plus a streak counter and a tasks-by-category breakdown.
- **Polished UI:** gradient dashboard banner with an animated progress ring, split-screen login, round countdown ring on the focus timer, hover effects, zebra-striped task table with priority symbols, toast notifications and a daily motivational line.
- **Pastel colour palettes:** four soft, colourful palettes (Lavender, Mint, Peach, Sky) picked with the coloured dots in the sidebar, each in a light and a dark mode. Your choice is remembered in `%USERPROFILE%\.flowday\settings.json`.
- **Dark/light themes:** switch from the left navigation.
- **SQLite storage:** data persists in `%USERPROFILE%\.flowday\flowday.db`.

## Run in VS Code on Windows

1. Install Python 3.10 or newer from [python.org](https://www.python.org/downloads/windows/) and select **Add python.exe to PATH** during setup. Tkinter is included with the standard Windows installer.
2. Open the `outputs` folder in VS Code (`File > Open Folder...`).
3. Open **Terminal > New Terminal**. In PowerShell, run:

```powershell
python --version
python -m smart_productivity
```

The exact equivalent launcher command is:

```powershell
python .\run_flowday.py
```

If `python` is not recognized, try `py -3` in place of `python`, for example `py -3 -m smart_productivity`.

## Run checks

From the `outputs` folder:

```powershell
python -m compileall .\smart_productivity .\run_flowday.py
python -m unittest discover -s .\tests -v
```

## Project layout

```text
outputs/
├── README.md
├── Start_Flowday.bat           # double-click launcher
├── run_flowday.py              # direct launcher
├── smart_productivity/
│   ├── __init__.py
│   ├── __main__.py             # python -m entry point
│   ├── app.py                  # Tkinter views and interactions
│   ├── database.py             # SQLite repository
│   └── models.py               # task model and priority strategy
└── tests/
    └── test_core.py            # database and priority checks
```

## OOP concepts in the code

- **Classes and objects:** `Task`, `SQLiteTaskRepository`, and `ProductivityApp` are instantiated and work together.
- **Encapsulation:** task state changes use `mark_complete`, `mark_incomplete`, and `set_priority`; database access is contained in the repository.
- **Inheritance:** `SQLiteTaskRepository` implements `TaskRepository`, and `DeadlinePriorityStrategy` extends `PriorityStrategy`.
- **Abstraction:** `TaskRepository` and `PriorityStrategy` define contracts without committing callers to storage or priority implementation details.
- **Polymorphism:** any `PriorityStrategy` implementation can be passed to the app in place of `DeadlinePriorityStrategy`; `calculate()` provides the same interface for different algorithms.

## Notes

Dates use ISO format (`YYYY-MM-DD`) and times use 24-hour format (`HH:MM`). Closing the app does not lose tasks or study blocks. Reminders are in-app popups and appear while Flowday is running.
