@echo off
cd /d "%~dp0"
title Flowday - Smart Productivity Tracker
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m smart_productivity
) else (
  python -m smart_productivity
)
if errorlevel 1 (
  echo.
  echo Flowday could not start. Please install Python 3.10+ and enable Add Python to PATH.
  echo Tkinter is included with the standard Windows Python installer.
  pause
)
