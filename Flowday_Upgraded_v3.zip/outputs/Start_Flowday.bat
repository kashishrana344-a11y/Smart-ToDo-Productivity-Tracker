@echo off
cd /d "%~dp0"
python run_flowday.py
if errorlevel 1 pause
