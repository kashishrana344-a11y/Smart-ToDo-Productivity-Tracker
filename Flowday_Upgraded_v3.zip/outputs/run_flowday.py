"""Launcher: run with python run_flowday.py from the outputs directory."""
from smart_productivity.__main__ import main
if __name__ == "__main__": main()
